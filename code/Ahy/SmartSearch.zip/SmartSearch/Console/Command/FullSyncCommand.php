<?php
declare(strict_types=1);

namespace Ahy\SmartSearch\Console\Command;

use Ahy\SmartSearch\Helper\Data;
use Ahy\SmartSearch\Service\ProductSyncService;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * bin/magento smartsearch:sync:full           — smart sync (only products updated since last run)
 * bin/magento smartsearch:sync:full --force   — force send ALL products regardless of cursor
 * bin/magento smartsearch:sync:full --store=1 — specific Magento store
 *
 * Default behaviour uses updated_at > last_sync_at for speed.
 * --force ignores the cursor and sends every product (use for first-time or recovery).
 */
class FullSyncCommand extends Command
{
    private const BATCH_SIZE = 500;

    public function __construct(
        private readonly Data               $helper,
        private readonly ProductSyncService $syncService,
        private readonly CollectionFactory  $collectionFactory,
    ) {
        parent::__construct();
    }

    protected function configure(): void
    {
        $this->setName('smartsearch:sync:full')
             ->setDescription('Sync Magento products to the search platform via ingest API.')
             ->addOption('force', null, InputOption::VALUE_NONE, 'Ignore cursor — send ALL products regardless of updated_at')
             ->addOption('store', null, InputOption::VALUE_OPTIONAL, 'Magento store ID', 0);
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $storeId = (int) $input->getOption('store');
        $force   = (bool) $input->getOption('force');

        if (!$this->helper->isEnabled()) {
            $output->writeln('<comment>[SmartSearch] Sync is disabled. Enable at Stores → Config → Ahy → Smart Search.</comment>');
            return 1;
        }

        // Always use cursor for speed; --force overrides to send everything
        $lastSyncAt    = $force ? null : $this->helper->getLastSyncAt();
        $syncStartedAt = date('Y-m-d H:i:s');
        $mode          = $force ? 'Force-full (all products)' : 'Smart (updated since ' . ($lastSyncAt ?? 'beginning') . ')';

        $output->writeln("<info>[SmartSearch] Sync started — {$mode}</info>");

        $start        = microtime(true);
        $page         = 1;
        $totalIndexed = 0;
        $totalFailed  = 0;

        do {
            $collection = $this->buildCollection($lastSyncAt, $storeId, $page);
            $products   = array_values($collection->getItems());

            if (empty($products)) {
                break;
            }

            // Retry transient errors (network timeouts, 5xx) up to 3 times
            $count   = -3;
            $attempt = 0;
            while ($count === -3 && $attempt <= 3) {
                if ($attempt > 0) {
                    $sleep = min(60, 10 * $attempt);
                    $output->writeln(sprintf(
                        '<comment>[SmartSearch] Transient error on page %d, retrying in %ds (attempt %d/3)...</comment>',
                        $page, $sleep, $attempt
                    ));
                    sleep($sleep);
                }
                $count = $this->syncService->syncBatch($products, $storeId);
                $attempt++;
            }

            if ($count === -1) {
                // Fatal: bad API key, endpoint URL not set, or server completely unreachable
                $output->writeln('<error>[SmartSearch] Fatal error — check endpoint URL and API key. Aborting.</error>');
                return 1;
            }

            if ($count === -2) {
                // Product limit reached — not an error, just stop sending
                $output->writeln('<comment>[SmartSearch] Product limit reached on the platform. Remaining products skipped. Upgrade your plan to sync more.</comment>');
                break;
            }

            if ($count === -3) {
                // Still failing after 3 retries — skip this batch and continue
                $output->writeln(sprintf(
                    '<error>[SmartSearch] Page %d failed after 3 retries — skipping batch of %d products.</error>',
                    $page, count($products)
                ));
                $totalFailed += count($products);
                $page++;
                continue;
            }

            $totalIndexed += $count;
            $output->writeln(sprintf(
                '[SmartSearch] Page %d → sent %d products (running total: %d)',
                $page, $count, $totalIndexed
            ));

            $page++;
        } while (count($products) === self::BATCH_SIZE);

        // Advance cursor only when no batches were skipped
        if ($totalFailed === 0) {
            $this->helper->setLastSyncAt($syncStartedAt);
        }

        $elapsed = round(microtime(true) - $start, 1);
        $output->writeln(sprintf(
            '<info>[SmartSearch] Done in %ss — sent: %d, failed: %d</info>',
            $elapsed, $totalIndexed, $totalFailed
        ));

        return $totalFailed === 0 ? 0 : 1;
    }

    private function buildCollection(?string $lastSyncAt, int $storeId, int $page): \Magento\Catalog\Model\ResourceModel\Product\Collection
    {
        $collection = $this->collectionFactory->create();

        if ($storeId > 0) {
            $collection->setStoreId($storeId);
            $collection->addStoreFilter($storeId);
        }

        $collection->addAttributeToSelect([
            'name', 'sku', 'price', 'special_price', 'status', 'visibility',
            'url_key', 'description', 'short_description', 'image',
            'color', 'material', 'size', 'manufacturer', 'product_brand',
        ]);

        // Sync all enabled products — including visibility=1 variants
        $collection->addAttributeToFilter('status', \Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_ENABLED);

        if ($lastSyncAt !== null) {
            $collection->addAttributeToFilter('updated_at', ['gt' => $lastSyncAt]);
        }

        $collection->setOrder('entity_id', 'ASC');
        $collection->setPageSize(self::BATCH_SIZE);
        $collection->setCurPage($page);

        return $collection;
    }
}
