<?php
declare(strict_types=1);

namespace Ahy\SmartSearch\Service;

use Ahy\SmartSearch\Helper\Data;
use Magento\Catalog\Model\Product;
use Magento\CatalogInventory\Api\StockRegistryInterface;
use Magento\CatalogInventory\Api\Data\StockItemInterface;
use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory as CategoryCollectionFactory;
use Magento\UrlRewrite\Model\UrlFinderInterface;
use Psr\Log\LoggerInterface;

class ProductSyncService
{
    public function __construct(
        private readonly Data                      $helper,
        private readonly StockRegistryInterface    $stockRegistry,
        private readonly CategoryCollectionFactory $categoryCollectionFactory,
        private readonly LoggerInterface           $logger,
        private readonly UrlFinderInterface        $urlFinder,
    ) {}

    /**
     * Normalize a Magento product and POST it to the platform ingest endpoint.
     * Returns true on success, false on failure (never throws — must not break product save).
     */
    public function sync(Product $product, int $magentoStoreId = 0, ?StockItemInterface $stockItem = null): bool
    {
        $endpointUrl     = $this->helper->getEndpointUrl($magentoStoreId);
        $apiKey          = $this->helper->getApiKey($magentoStoreId);
        $platformStoreId = $this->helper->getPlatformStoreId($magentoStoreId);

        if (!$endpointUrl || !$apiKey) {
            $this->logger->warning('[SmartSearch] Sync skipped: endpoint URL or API key not configured.');
            return false;
        }

        try {
            $payload = [
                'batch_id' => $this->uuid4(),
                'store_id' => $platformStoreId,
                'realtime' => true,
                'products' => [$this->normalize($product, $magentoStoreId, $stockItem)],
            ];

            $code = $this->post($endpointUrl, $apiKey, $payload);
            return $code >= 200 && $code < 300;
        } catch (\Throwable $e) {
            $this->logger->error('[SmartSearch] Sync failed for product ' . $product->getId() . ': ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Normalize and POST a batch of products in one request.
     *
     * Return codes:
     *   >= 0  : number of products accepted
     *   -1    : fatal config error (no URL / no key / 401 auth failure) — abort sync
     *   -2    : product limit reached (403) — stop sending, don't abort
     *   -3    : transient error (5xx / network timeout) — caller should retry
     */
    public function syncBatch(array $products, int $magentoStoreId = 0): int
    {
        if (empty($products)) {
            return 0;
        }

        $endpointUrl     = $this->helper->getEndpointUrl($magentoStoreId);
        $apiKey          = $this->helper->getApiKey($magentoStoreId);
        $platformStoreId = $this->helper->getPlatformStoreId($magentoStoreId);

        if (!$endpointUrl || !$apiKey) {
            $this->logger->warning('[SmartSearch] Batch sync skipped: endpoint URL or API key not configured.');
            return -1;
        }

        $normalized = [];
        foreach ($products as $product) {
            try {
                $normalized[] = $this->normalize($product, $magentoStoreId);
            } catch (\Throwable $e) {
                $this->logger->warning('[SmartSearch] Could not normalize product ' . $product->getId() . ': ' . $e->getMessage());
            }
        }

        if (empty($normalized)) {
            return 0;
        }

        try {
            $payload = [
                'batch_id' => $this->uuid4(),
                'store_id' => $platformStoreId,
                'products' => $normalized,
            ];

            $httpCode = $this->post($endpointUrl, $apiKey, $payload);

            if ($httpCode >= 200 && $httpCode < 300) {
                return count($normalized);
            }
            if ($httpCode === 401 || $httpCode === 0) {
                return -1; // fatal — bad key or no connection
            }
            if ($httpCode === 403) {
                return -2; // product limit reached
            }
            if ($httpCode === 429) {
                return -3; // rate limited — transient
            }
            return -3; // 5xx or other — transient
        } catch (\Throwable $e) {
            $this->logger->error('[SmartSearch] Batch sync exception: ' . $e->getMessage());
            return -3;
        }
    }

    // -------------------------------------------------------------------------

    private function normalize(Product $product, int $magentoStoreId, ?StockItemInterface $preloadedStockItem = null): array
    {
        $productId = (int) $product->getId();
        // Use the pre-loaded stock item when provided (e.g. from StockChangeObserver) to avoid
        // reading the stale in-memory StockRegistry cache within the same request.
        $stockItem = $preloadedStockItem ?? $this->stockRegistry->getStockItem($productId);
        $inStock   = (bool) $stockItem->getIsInStock();
        $qty       = (int) $stockItem->getQty();


        // Categories
        $categories = $this->buildCategories($product->getCategoryIds(), $magentoStoreId);

        // Brand: try product_brand first, then manufacturer
        $brand = '';
        foreach (['product_brand', 'manufacturer'] as $brandAttr) {
            if ($product->getData($brandAttr)) {
                $text = $product->getAttributeText($brandAttr);
                if (is_array($text)) $text = implode(', ', $text);
                $brand = ($text !== false && $text !== '') ? (string) $text : (string) $product->getData($brandAttr);
                if ($brand !== '') break;
            }
        }

        // Attributes — dynamically pulled from all product EAV attributes,
        // matching the exact format the import scripts write:
        //   name  = frontend_label  (e.g. "Color", not "color")
        //   value = resolved option label for select/swatch, raw value for varchar/decimal
        $excludedAttributeCodes = [
            'status', 'visibility', 'tax_class_id', 'quantity_and_stock_status',
            'price', 'special_price', 'news_from_date', 'news_to_date',
            'special_from_date', 'special_to_date',
            'name', 'description', 'short_description',
            'url_key', 'url_path',
            'image', 'small_image', 'thumbnail', 'swatch_image',
            'meta_title', 'meta_description', 'meta_keyword',
            'category_ids', 'required_options', 'has_options',
            'created_at', 'updated_at',
            'country_of_manufacture', 'msrp', 'msrp_display_actual_price_type',
            'price_type', 'price_view', 'sku_type', 'weight_type',
            'shipment_type', 'links_purchased_separately', 'links_title',
            'samples_title', 'gift_message_available', 'product_from',
        ];

        $attributes = [];
        foreach ($product->getAttributes() as $attribute) {
            $code  = $attribute->getAttributeCode();
            $label = (string) $attribute->getFrontendLabel();
            $input = $attribute->getFrontendInput();

            // Skip system/excluded attributes and anything without a visible label
            if (in_array($code, $excludedAttributeCodes, true) || $label === '') {
                continue;
            }

            $val = $product->getData($code);
            if ($val === null || $val === '' || $val === false) {
                continue;
            }

            // Select/multiselect/swatch — resolve option_id to label
            if (in_array($input, ['select', 'multiselect', 'swatch_visual', 'swatch_text'], true)) {
                $text = $product->getAttributeText($code);
                if ($text === false || $text === '') {
                    continue;
                }
                $value = is_array($text) ? implode(', ', $text) : (string) $text;
            } else {
                // varchar / decimal / text — use raw value
                $value = is_array($val) ? implode(', ', $val) : (string) $val;
                if ($value === '') {
                    continue;
                }
            }

            $attributes[] = [
                'name'  => $label,
                'value' => $value,
            ];
        }

        // Variants (configurable children)
        $variants = [];
        if ($product->getTypeId() === 'configurable') {
            foreach ($product->getTypeInstance()->getUsedProducts($product) as $child) {
                $childStock = $this->stockRegistry->getStockItem((int) $child->getId());
                $variants[] = [
                    'variant_id'    => (string) $child->getId(),
                    'name'          => (string) ($child->getName() ?: $product->getName()),
                    'sku'           => (string) $child->getSku(),
                    'price'         => (float) ($child->getPrice() ?: $product->getPrice()),
                    'special_price' => $child->getSpecialPrice() !== null ? (float) $child->getSpecialPrice() : null,
                    'in_stock'      => (bool) $childStock->getIsInStock(),
                    'qty'           => (int) $childStock->getQty(),
                ];
            }

            $qty = 0;
        }

        // visibility=1 means "Not Visible Individually" — these are child/variant products
        $isVariant = ((int) $product->getVisibility() === 1);

        return [
            'product_id'        => (string) $product->getId(),
            'sku'               => (string) $product->getSku(),
            'type'              => (string) $product->getTypeId(),
            'name'              => (string) $product->getName(),
            'price'             => (float) $product->getPrice(),
            'special_price'     => $product->getSpecialPrice() !== null ? (float) $product->getSpecialPrice() : null,
            'in_stock'          => $inStock,
            'qty'               => $qty,
            'visibility'        => (int) $product->getVisibility(),
            'is_variant'        => $isVariant,
            'status'            => (int) $product->getStatus(),
            'brand'             => $brand,
            'url_key'           => $this->resolveUrlKey($product, $magentoStoreId),
            'description'       => strip_tags((string) ($product->getData('description') ?: '')),
            'short_description' => strip_tags((string) ($product->getData('short_description') ?: '')),
            'images'            => ['main_image' => (string) ($product->getData('image') ?: '')],
            'categories'        => $categories,
            'attributes'        => $attributes,
            'variants'          => $variants,
        ];
    }

    private function buildCategories(array $categoryIds, int $storeId): array
    {
        if (empty($categoryIds)) {
            return [];
        }

        try {
            // Load the leaf categories the product belongs to
            $collection = $this->categoryCollectionFactory->create();
            $collection->addAttributeToFilter('entity_id', ['in' => $categoryIds])
                       ->addAttributeToSelect(['name', 'path'])
                       ->setStoreId($storeId);

            // Collect every ancestor ID we'll need to resolve full paths
            $allAncestorIds = [];
            foreach ($collection as $cat) {
                // path = "1/2/10/45" — strip root (depth 0) and root category (depth 1)
                $ids = array_slice(explode('/', $cat->getPath()), 2);
                foreach ($ids as $id) {
                    $allAncestorIds[(int)$id] = true;
                }
            }

            // Load all ancestor names in a single query
            $nameMap = [];
            if (!empty($allAncestorIds)) {
                $ancestors = $this->categoryCollectionFactory->create();
                $ancestors->addAttributeToFilter('entity_id', ['in' => array_keys($allAncestorIds)])
                          ->addAttributeToSelect(['name'])
                          ->setStoreId($storeId);
                foreach ($ancestors as $anc) {
                    $nameMap[(int)$anc->getId()] = (string)$anc->getName();
                }
            }

            $categories = [];
            foreach ($collection as $cat) {
                $pathIds   = array_slice(explode('/', $cat->getPath()), 2);
                $pathNames = array_filter(array_map(
                    static fn($id) => $nameMap[(int)$id] ?? '',
                    $pathIds
                ));

                $categories[] = [
                    'id'   => (string) $cat->getId(),
                    'name' => (string) $cat->getName(),
                    'path' => implode(' > ', $pathNames),
                ];
            }

            return $categories;
        } catch (\Throwable $e) {
            $this->logger->warning('[SmartSearch] Could not load categories: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * POST payload to the platform endpoint.
     * Returns the HTTP status code, or 0 on a cURL/network error.
     */
    private function post(string $url, string $apiKey, array $payload): int
    {
        $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        $headers = [
            'Content-Type: application/json',
            'X-Api-Key: ' . $apiKey,
            'X-Signature: sha256=' . hash_hmac('sha256', $json, $apiKey),
        ];

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $json,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 120,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_HTTPHEADER     => $headers,
        ]);

        $raw      = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlErr  = curl_error($ch);
        curl_close($ch);

        if ($raw === false) {
            $this->logger->error('[SmartSearch] cURL error: ' . $curlErr);
            return 0;
        }

        if ($httpCode < 200 || $httpCode >= 300) {
            $this->logger->error("[SmartSearch] Platform returned HTTP {$httpCode}: " . substr((string) $raw, 0, 500));
        }

        return $httpCode;
    }

    private function uuid4(): string
    {
        $data    = random_bytes(16);
        $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }

    /**
     * Returns the product url_key. Falls back to url_rewrite lookup for products
     * imported without a url_key EAV attribute (getUrlKey() returns empty for those).
     */
    private function resolveUrlKey(Product $product, int $storeId): string
    {
        $urlKey = (string) $product->getUrlKey();
        if ($urlKey !== '') {
            return $urlKey;
        }

        try {
            $rewrite = $this->urlFinder->findOneByData([
                'entity_id'   => (int) $product->getId(),
                'entity_type' => 'product',
                'store_id'    => $storeId ?: 1,
            ]);
            if ($rewrite) {
                // request_path is like "logo-baseball-cap.html" — strip the suffix
                return preg_replace('/\.[^.]+$/', '', basename($rewrite->getRequestPath()));
            }
        } catch (\Throwable $e) {
            $this->logger->warning('[SmartSearch] url_rewrite lookup failed for product ' . $product->getId() . ': ' . $e->getMessage());
        }

        return '';
    }
}
