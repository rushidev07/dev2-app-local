<?php
declare(strict_types=1);

namespace Ahy\SmartSearch\Observer;

use Ahy\SmartSearch\Helper\Data;
use Ahy\SmartSearch\Service\ProductSyncService;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Psr\Log\LoggerInterface;

class StockChangeObserver implements ObserverInterface
{
    public function __construct(
        private readonly Data                      $helper,
        private readonly ProductSyncService        $syncService,
        private readonly ProductRepositoryInterface $productRepository,
        private readonly LoggerInterface           $logger,
    ) {}

    public function execute(Observer $observer): void
    {
        if (!$this->helper->isEnabled()) {
            return;
        }

        /** @var \Magento\CatalogInventory\Model\Stock\Item $stockItem */
        $stockItem = $observer->getEvent()->getItem();

        if (!$stockItem || !$stockItem->getProductId()) {
            return;
        }

        $origQty     = (float) $stockItem->getOrigData('qty');
        $currQty     = (float) $stockItem->getQty();
        $origInStock = (int) $stockItem->getOrigData('is_in_stock');
        $currInStock = (int) $stockItem->getIsInStock();

        if ($origQty === $currQty && $origInStock === $currInStock) {
            return;
        }

        $productId = (int) $stockItem->getProductId();

        $this->logger->info(sprintf(
            '[SmartSearch] Stock changed for product %d (qty: %s->%s, in_stock: %s->%s) — syncing.',
            $productId, $origQty, $currQty, $origInStock, $currInStock
        ));

        try {
            // Load fresh product, pass the event's stock item directly so normalize()
            // doesn't read the stale in-memory StockRegistry cache (still shows old value).
            $product = $this->productRepository->getById($productId, false, null, true);
            $this->syncService->sync($product, 0, $stockItem);
        } catch (\Throwable $e) {
            $this->logger->error('[SmartSearch] StockChangeObserver failed for product ' . $productId . ': ' . $e->getMessage());
        }
    }
}
