<?php
/**
 * Copyright © Ahy Consulting All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Ahy\SmartSearch\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Ahy\SmartSearch\Helper\Data;
use Psr\Log\LoggerInterface;

class LogApiKey implements ObserverInterface
{
    public function __construct(
        private Data $helper,
        private LoggerInterface $logger
    ) {}

    public function execute(Observer $observer): void
    {
        $apiKey = $this->helper->getApiKey();
        $this->logger->info('[SmartSearch] API Key: ' . $apiKey);
    }
}
