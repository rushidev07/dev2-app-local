<?php
declare(strict_types=1);

namespace Ahy\SmartSearch\Observer;

use Ahy\SmartSearch\Helper\Data;
use Ahy\SmartSearch\Model\AttributeChangeDetector;
use Ahy\SmartSearch\Service\ProductSyncService;
use Magento\Framework\Cache\FrontendInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Psr\Log\LoggerInterface;

class ProductSaveObserver implements ObserverInterface
{
    /**
     * Max real-time syncs per minute from observer.
     * Above this, the cron delta sync will catch up within 1 minute.
     * Prevents hammering the platform during bulk imports.
     */
    private const RATE_LIMIT_PER_MINUTE = 120;
    private const CACHE_KEY = 'smartsearch_observer_rate_';

    public function __construct(
        private readonly Data                    $helper,
        private readonly AttributeChangeDetector $changeDetector,
        private readonly ProductSyncService      $syncService,
        private readonly FrontendInterface       $cache,
        private readonly LoggerInterface         $logger,
    ) {}

    public function execute(Observer $observer): void
    {
        /** @var \Magento\Catalog\Model\Product $product */
        $product = $observer->getEvent()->getProduct();

        if (!$product || !$product->getId()) {
            return;
        }

        $storeId = (int) $product->getStoreId();

        if (!$this->helper->isEnabled($storeId)) {
            return;
        }

        // Rate limit: skip real-time sync if too many saves this minute.
        // The cron delta sync will pick it up within 1 minute anyway.
        if (!$this->isWithinRateLimit($storeId)) {
            $this->logger->warning(sprintf(
                '[SmartSearch] Rate limit reached (%d/min) — product %d will sync via cron.',
                self::RATE_LIMIT_PER_MINUTE,
                $product->getId()
            ));
            return;
        }

        // Sync if a search-relevant field (name/price/special_price/status) changed,
        // OR if stock_data is present — Magento sets this whenever the admin saves
        // the product form, meaning the user may have changed in_stock/qty.
        // StockChangeObserver handles stock item events, but misses the case where
        // stock was already 0 (no delta). This catches that gap.
        $stockDataPresent = is_array($product->getData('stock_data'));
        if (!$stockDataPresent && !$this->changeDetector->hasRelevantChange($product)) {
            return;
        }

        $this->logger->info(sprintf(
            '[SmartSearch] Product %d (%s) saved — syncing to platform.',
            $product->getId(),
            $product->getSku()
        ));

        $this->syncService->sync($product, $storeId);
    }

    private function isWithinRateLimit(int $storeId): bool
    {
        $bucket  = date('YmdHi'); // changes every minute
        $cacheKey = self::CACHE_KEY . $storeId . '_' . $bucket;

        $current = (int) ($this->cache->load($cacheKey) ?: 0);

        if ($current >= self::RATE_LIMIT_PER_MINUTE) {
            return false;
        }

        // Increment counter, expire at end of current minute + 5s buffer
        $ttl = 65 - (int) date('s');
        $this->cache->save((string) ($current + 1), $cacheKey, [], $ttl);

        return true;
    }
}
