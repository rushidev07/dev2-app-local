<?php
declare(strict_types=1);

namespace Ahy\SmartSearch\Observer;

use Ahy\SmartSearch\Helper\Data;
use Ahy\SmartSearch\Service\CustomerEventService;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Magento\Store\Model\StoreManagerInterface;
use Psr\Log\LoggerInterface;

/**
 * Fires on: customer_logout (frontend scope)
 * Event data: customer — Magento\Customer\Model\Customer
 */
class CustomerLogoutObserver implements ObserverInterface
{
    public function __construct(
        private readonly Data                  $helper,
        private readonly CustomerEventService  $eventService,
        private readonly StoreManagerInterface $storeManager,
        private readonly LoggerInterface       $logger,
    ) {}

    public function execute(Observer $observer): void
    {
        if (!$this->helper->isEnabled()) {
            return;
        }

        try {
            $customer = $observer->getData('customer');
            if (!$customer || !$customer->getId()) {
                return;
            }

            $storeId = (int) $this->storeManager->getStore()->getId();

            $this->eventService->trackLogout(
                customerId: (int) $customer->getId(),
                storeId:    $storeId
            );
        } catch (\Throwable $e) {
            $this->logger->error('[SmartSearch][Events] CustomerLogout observer error: ' . $e->getMessage());
        }
    }
}
