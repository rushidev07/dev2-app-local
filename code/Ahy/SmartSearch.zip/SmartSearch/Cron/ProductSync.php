<?php
declare(strict_types=1);

namespace Ahy\SmartSearch\Cron;

use Ahy\SmartSearch\Helper\Data;
use Ahy\SmartSearch\Service\ProductSyncService;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Psr\Log\LoggerInterface;

/**
 * Delta sync — runs every 15 minutes via cron, sends only products changed
 * since the last successful run to POST /api/v1/ingest/products.
 * Full sync: bin/magento smartsearch:sync:full
 */
class ProductSync
{
    private const BATCH_SIZE = 500;

    public function __construct(
        private readonly Data               $helper,
        private readonly ProductSyncService $syncService,
        private readonly CollectionFactory  $collectionFactory,
        private readonly LoggerInterface    $logger,
    ) {}

    public function execute(): void
    {
        if (!$this->helper->isEnabled()) {
            return;
        }

        $syncStartedAt = date('Y-m-d H:i:s');
        $forceFullSync = $this->helper->isFullSyncRequested();

        // Full sync requested via admin button — ignore cursor
        $lastSyncAt = $forceFullSync ? null : $this->helper->getLastSyncAt();

        $this->logger->info(sprintf(
            '[SmartSearch][Cron] Sync started. mode=%s cursor=%s',
            $forceFullSync ? 'full' : 'delta',
            $lastSyncAt ?? 'none'
        ));

        $page        = 1;
        $totalSynced = 0;

        do {
            $collection = $this->buildCollection($lastSyncAt, $page);
            $products   = array_values($collection->getItems());

            if (empty($products)) {
                break;
            }

            $count = $this->syncService->syncBatch($products);

            if ($count === -1) {
                $this->logger->error('[SmartSearch][Cron] Config/connection error — aborting run, cursor not advanced.');
                return;
            }

            $totalSynced += $count;
            $page++;
        } while (count($products) === self::BATCH_SIZE);

        $this->helper->setLastSyncAt($syncStartedAt);

        if ($forceFullSync) {
            $this->helper->clearFullSyncFlag();
        }

        $this->logger->info('[SmartSearch][Cron] Done. synced=' . $totalSynced . ' cursor=' . $syncStartedAt);
    }

    private function buildCollection(?string $lastSyncAt, int $page): \Magento\Catalog\Model\ResourceModel\Product\Collection
    {
        $collection = $this->collectionFactory->create();

        $collection->addAttributeToSelect([
            'name', 'sku', 'price', 'special_price', 'status', 'visibility',
            'url_key', 'description', 'short_description', 'image',
            'color', 'material', 'size', 'manufacturer', 'product_brand',
        ]);

        if ($lastSyncAt !== null) {
            $collection->addAttributeToFilter('updated_at', ['gt' => $lastSyncAt]);
        }

        $collection->setOrder('entity_id', 'ASC');
        $collection->setPageSize(self::BATCH_SIZE);
        $collection->setCurPage($page);

        return $collection;
    }
}

