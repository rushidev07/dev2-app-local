<?php
declare(strict_types=1);

namespace Ahy\SmartSearch\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Config\Storage\WriterInterface;
use Magento\Store\Model\ScopeInterface;

class Data extends AbstractHelper
{
    private const XML_PATH_ENABLED          = 'smart_search/general/enabled';
    private const XML_PATH_ENDPOINT_URL     = 'smart_search/general/endpoint_url';
    private const XML_PATH_SEARCH_URL       = 'smart_search/general/search_url';
    private const XML_PATH_API_KEY          = 'smart_search/general/api_key';
    private const XML_PATH_PLATFORM_STORE   = 'smart_search/general/platform_store_id';
    private const XML_PATH_WEBHOOK_SECRET   = 'smart_search/webhook/secret';
    private const XML_PATH_LAST_SYNC_AT     = 'smart_search/cron/last_sync_at';
    private const XML_PATH_FULL_SYNC_FLAG   = 'smart_search/cron/full_sync_requested';

    private ScopeConfigInterface $config;
    private WriterInterface $configWriter;

    public function __construct(
        Context $context,
        ScopeConfigInterface $scopeConfig,
        WriterInterface $configWriter
    ) {
        parent::__construct($context);
        $this->config       = $scopeConfig;
        $this->configWriter = $configWriter;
    }

    public function isEnabled(int|string|null $storeId = null): bool
    {
        return $this->config->isSetFlag(self::XML_PATH_ENABLED, ScopeInterface::SCOPE_STORE, $storeId);
    }

    public function getSearchUrl(int|string|null $storeId = null): string
    {
        return (string) $this->config->getValue(self::XML_PATH_SEARCH_URL, ScopeInterface::SCOPE_STORE, $storeId);
    }

    public function getEndpointUrl(int|string|null $storeId = null): string
    {
        return (string) $this->config->getValue(self::XML_PATH_ENDPOINT_URL, ScopeInterface::SCOPE_STORE, $storeId);
    }

    /**
     * Derive the platform events endpoint from the ingest URL base.
     * e.g. http://host.docker.internal:8080/api/v1/ingest/products → http://host.docker.internal:8080/api/v1/events
     */
    public function getEventsEndpointUrl(int|string|null $storeId = null): string
    {
        $ingest = $this->getEndpointUrl($storeId);
        if (!$ingest) {
            return '';
        }
        $parts = parse_url($ingest);
        $base  = ($parts['scheme'] ?? 'http') . '://' . ($parts['host'] ?? 'localhost');
        if (!empty($parts['port'])) {
            $base .= ':' . $parts['port'];
        }
        return $base . '/api/v1/events';
    }

    public function getApiKey(int|string|null $storeId = null): string
    {
        return (string) $this->config->getValue(self::XML_PATH_API_KEY, ScopeInterface::SCOPE_STORE, $storeId);
    }

    public function getPlatformStoreId(int|string|null $storeId = null): int
    {
        return (int) ($this->config->getValue(self::XML_PATH_PLATFORM_STORE, ScopeInterface::SCOPE_STORE, $storeId) ?: 1);
    }

    public function getWebhookSecret(): string
    {
        return (string) $this->config->getValue(self::XML_PATH_WEBHOOK_SECRET, ScopeConfigInterface::SCOPE_TYPE_DEFAULT);
    }

    /**
     * Returns the last successful cron sync timestamp, or null if never synced (triggers full sync).
     */
    public function getLastSyncAt(): ?string
    {
        $value = $this->config->getValue(self::XML_PATH_LAST_SYNC_AT, ScopeConfigInterface::SCOPE_TYPE_DEFAULT);
        return ($value && $value !== '') ? (string) $value : null;
    }

    /**
     * Persists the sync cursor. Call with the timestamp recorded at cron start (not end)
     * so products updated during the run are caught on the next run.
     */
    public function setLastSyncAt(string $datetime): void
    {
        $this->configWriter->save(self::XML_PATH_LAST_SYNC_AT, $datetime, ScopeConfigInterface::SCOPE_TYPE_DEFAULT, 0);
    }

    public function isFullSyncRequested(): bool
    {
        return (bool) $this->config->getValue(self::XML_PATH_FULL_SYNC_FLAG, ScopeConfigInterface::SCOPE_TYPE_DEFAULT);
    }

    public function requestFullSync(): void
    {
        $this->configWriter->save(self::XML_PATH_FULL_SYNC_FLAG, 1, ScopeConfigInterface::SCOPE_TYPE_DEFAULT, 0);
    }

    public function clearFullSyncFlag(): void
    {
        $this->configWriter->save(self::XML_PATH_FULL_SYNC_FLAG, 0, ScopeConfigInterface::SCOPE_TYPE_DEFAULT, 0);
    }
}
