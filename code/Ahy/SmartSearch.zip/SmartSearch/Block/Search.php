<?php
declare(strict_types=1);

namespace Ahy\SmartSearch\Block;

use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Ahy\SmartSearch\Helper\Data as SmartSearchHelper;

class Search extends Template
{
    private SmartSearchHelper $helper;

    public function __construct(Context $context, SmartSearchHelper $helper, array $data = [])
    {
        parent::__construct($context, $data);
        $this->helper = $helper;
    }

    public function getSearchApiUrl(): string
    {
        $url = $this->helper->getSearchUrl();
        return $url ?: 'http://localhost:8001/api/search.php';
    }

    public function getApiKey(): string
    {
        return $this->helper->getApiKey();
    }

    public function getProductsApiUrl(): string
    {
        $endpoint = $this->helper->getEndpointUrl();
        if (!$endpoint) {
            return 'http://localhost:8080/api/v1/products';
        }
        $parts = parse_url($endpoint);
        $base  = ($parts['scheme'] ?? 'http') . '://' . ($parts['host'] ?? 'localhost');
        if (!empty($parts['port'])) {
            $base .= ':' . $parts['port'];
        }
        return $base . '/api/v1/products';
    }

    public function getPlatformStoreId(): int
    {
        return $this->helper->getPlatformStoreId();
    }

    public function getSearchAnalyticsUrl(): string
    {
        $endpoint = $this->helper->getEndpointUrl();
        if (!$endpoint) {
            return 'http://localhost:8080/api/v1/analytics/search';
        }
        $parts = parse_url($endpoint);
        $base  = ($parts['scheme'] ?? 'http') . '://' . ($parts['host'] ?? 'localhost');
        if (!empty($parts['port'])) {
            $base .= ':' . $parts['port'];
        }
        return $base . '/api/v1/analytics/search';
    }

    public function getSearchQuery(): string
    {
        return (string) ($this->getRequest()->getParam('q') ?? '');
    }
}
