<?php
declare(strict_types=1);

namespace Ahy\SmartSearch\Block\Adminhtml\System\Config;

use Magento\Backend\Block\Template\Context;
use Magento\Config\Block\System\Config\Form\Field;
use Magento\Framework\Data\Form\Element\AbstractElement;

class SyncAllButton extends Field
{
    public function __construct(Context $context, array $data = [])
    {
        parent::__construct($context, $data);
    }

    public function render(AbstractElement $element): string
    {
        $element->unsScope()->unsCanUseWebsiteValue()->unsCanUseDefaultValue();
        return parent::render($element);
    }

    protected function _getElementHtml(AbstractElement $element): string
    {
        $syncUrl = $this->getUrl('smartsearch/sync/fullsync');

        return <<<HTML
<button type="button"
        id="ss-sync-btn"
        class="action-default scalable"
        onclick="ssTriggerSync(this, '{$syncUrl}')">
    <span>Sync All Products Now</span>
</button>
<span id="ss-sync-msg" style="margin-left:12px;font-weight:600;font-size:13px;"></span>

<script type="text/javascript">
function ssTriggerSync(btn, url) {
    btn.disabled = true;
    btn.querySelector('span').textContent = 'Queuing...';
    document.getElementById('ss-sync-msg').textContent = '';
    document.getElementById('ss-sync-msg').style.color = '#374151';

    var xhr = new XMLHttpRequest();
    xhr.open('POST', url, true);
    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.withCredentials = true;
    xhr.onreadystatechange = function() {
        if (xhr.readyState !== 4) { return; }
        btn.disabled = false;
        btn.querySelector('span').textContent = 'Sync All Products Now';
        var msg = document.getElementById('ss-sync-msg');
        try {
            var data = JSON.parse(xhr.responseText);
            msg.textContent = data.message || (data.success ? 'Queued.' : 'Failed.');
            msg.style.color  = data.success ? '#065f46' : '#991b1b';
        } catch(e) {
            msg.textContent = 'Unexpected response.';
            msg.style.color  = '#991b1b';
        }
    };
    var fk = document.querySelector('input[name="form_key"]');
    xhr.send('form_key=' + encodeURIComponent(fk ? fk.value : ''));
}
</script>
HTML;
    }
}
