<?php
declare(strict_types=1);

namespace Ahy\SmartSearch\Controller\Adminhtml\Sync;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\CsrfAwareActionInterface;
use Magento\Framework\App\Request\InvalidRequestException;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Controller\Result\JsonFactory;

class Status extends Action implements CsrfAwareActionInterface
{
    public const ADMIN_RESOURCE = 'Ahy_SmartSearch::config';

    public function __construct(
        Context             $context,
        private readonly JsonFactory $jsonFactory,
    ) {
        parent::__construct($context);
    }

    public function createCsrfValidationException(RequestInterface $request): ?InvalidRequestException
    {
        return null;
    }

    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
    }

    protected function _validateSecretKey(): bool
    {
        return true;
    }

    public function execute(): \Magento\Framework\Controller\Result\Json
    {
        $result  = $this->jsonFactory->create();
        $logFile = BP . '/var/log/smartsearch-full-sync.log';

        if (!file_exists($logFile)) {
            return $result->setData(['done' => false, 'log' => '', 'sent' => 0, 'total' => 0]);
        }

        // Read last 20 lines for the log box
        $lines   = $this->tailFile($logFile, 20);
        $lastLog = implode("\n", $lines);

        // Parse progress from lines like: [SmartSearch] Page 3 → sent 1500 products (running total: 1500)
        $sent  = 0;
        $total = 0;
        foreach (array_reverse($lines) as $line) {
            if (preg_match('/running total:\s*(\d+)/', $line, $m)) {
                $sent = (int) $m[1];
                break;
            }
        }

        // Check if done
        $done    = false;
        $message = '';
        foreach (array_reverse($lines) as $line) {
            if (preg_match('/Done in .* sent:\s*(\d+)/', $line, $m)) {
                $done    = true;
                $sent    = (int) $m[1];
                $message = trim(preg_replace('/\[SmartSearch\]/', '', strip_tags($line)));
                break;
            }
        }

        return $result->setData([
            'done'    => $done,
            'message' => $message,
            'sent'    => $sent,
            'total'   => $total,
            'log'     => $lastLog,
        ]);
    }

    private function tailFile(string $file, int $lines): array
    {
        $fp   = fopen($file, 'rb');
        $buf  = '';
        $size = filesize($file);
        if (!$fp || $size === 0) {
            return [];
        }
        $chunk = min(4096, $size);
        fseek($fp, -$chunk, SEEK_END);
        $buf  = fread($fp, $chunk);
        fclose($fp);
        $all = explode("\n", trim($buf));
        return array_slice($all, -$lines);
    }
}
