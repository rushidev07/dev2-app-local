<?php
declare(strict_types=1);

namespace Ahy\SmartSearch\Controller\Adminhtml\Sync;

use Ahy\SmartSearch\Helper\Data;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\CsrfAwareActionInterface;
use Magento\Framework\App\Request\InvalidRequestException;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Controller\Result\JsonFactory;

class FullSync extends Action implements CsrfAwareActionInterface
{
    public const ADMIN_RESOURCE = 'Ahy_SmartSearch::config';

    public function __construct(
        Context             $context,
        private readonly JsonFactory $jsonFactory,
        private readonly Data        $helper,
    ) {
        parent::__construct($context);
    }

    public function createCsrfValidationException(RequestInterface $request): ?InvalidRequestException
    {
        return null;
    }

    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
    }

    protected function _validateSecretKey(): bool
    {
        return true;
    }

    public function execute(): \Magento\Framework\Controller\Result\Json
    {
        $result = $this->jsonFactory->create();

        if (!$this->helper->isEnabled()) {
            return $result->setData(['success' => false, 'message' => 'SmartSearch sync is disabled in config.']);
        }

        try {
            $this->helper->requestFullSync();

            return $result->setData([
                'success' => true,
                'message' => 'Full sync queued. It will run on the next Magento cron execution.',
            ]);
        } catch (\Throwable $e) {
            return $result->setData(['success' => false, 'message' => $e->getMessage()]);
        }
    }
}
