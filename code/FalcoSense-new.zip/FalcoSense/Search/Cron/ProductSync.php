<?php
declare(strict_types=1);

namespace FalcoSense\Search\Cron;

use FalcoSense\Search\Helper\Data;
use FalcoSense\Search\Service\DisabledParentResolver;
use FalcoSense\Search\Service\ProductSyncService;
use FalcoSense\Search\Service\SyncLockManager;
use Magento\Catalog\Model\Product\Attribute\Source\Status;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Store\Model\StoreManagerInterface;
use Psr\Log\LoggerInterface;

/**
 * Delta sync — runs every minute via cron, sends only products changed
 * since the last successful run to POST /api/v1/ingest/products.
 * Loops every store that has its own (or an inherited default) API key configured,
 * so each store's products sync under that store's key/platform store id.
 * Full sync: bin/magento smartsearch:sync:full
 */
class ProductSync
{
    private const BATCH_SIZE = 500;

    public function __construct(
        private readonly Data                  $helper,
        private readonly ProductSyncService    $syncService,
        private readonly CollectionFactory     $collectionFactory,
        private readonly LoggerInterface       $logger,
        private readonly SyncLockManager       $lockManager,
        private readonly StoreManagerInterface $storeManager,
        private readonly DisabledParentResolver $disabledParentResolver,
    ) {}

    public function execute(): void
    {
        if (!$this->helper->isEnabled()) {
            return;
        }

        if (!$this->lockManager->acquireOrTakeOver('cron')) {
            $info = $this->lockManager->getLockInfo();
            $this->logger->warning(sprintf(
                '[SmartSearch][Cron] Sync already running (via %s, started %s) — skipping.',
                $info['source']  ?? 'unknown',
                $info['started'] ?? 'unknown'
            ));
            return;
        }

        $lockManager = $this->lockManager;
        register_shutdown_function(static function () use ($lockManager): void {
            $lockManager->release();
        });

        $syncStartedAt = date('Y-m-d H:i:s');
        $forceFullSync = $this->helper->isFullSyncRequested();
        $lastSyncAt    = $forceFullSync ? null : $this->helper->getLastSyncAt();

        $storeIds = $this->getConfiguredStoreIds();

        if (empty($storeIds)) {
            $this->logger->warning('[SmartSearch][Cron] No stores with an API key configured — skipping.');
            $this->lockManager->writeResult(false, 'No stores with an API key configured.');
            $this->lockManager->release();
            return;
        }

        $this->logger->info(sprintf(
            '[SmartSearch][Cron] Sync started. mode=%s cursor=%s stores=%s',
            $forceFullSync ? 'full' : 'delta',
            $lastSyncAt ?? 'none',
            implode(',', $storeIds)
        ));

        $totalSynced = 0;
        $aborted     = false;
        $hadFatal    = false;

        try {
            foreach ($storeIds as $storeId) {
                if ($aborted) {
                    break;
                }

                $page = 1;

                // A configurable child keeps its own independent status attribute --
                // disabling the parent does NOT disable its children. Without this,
                // an individually-still-Enabled child would sync on its own even
                // though its parent (the only thing actually shown/sold) is Disabled.
                $orphanedChildIds = $this->disabledParentResolver->getOrphanedChildIds($storeId);
                $orphanedChildIdSet = array_flip($orphanedChildIds);
                if (!empty($orphanedChildIds)) {
                    $this->logger->info(sprintf(
                        '[SmartSearch][Cron] Excluding %d child product(s) of a disabled parent for store %d.',
                        count($orphanedChildIds),
                        $storeId
                    ));
                }

                do {
                    if (!$this->lockManager->isLocked()) {
                        $this->logger->warning('[SmartSearch][Cron] Lock file removed — sync aborted by external signal.');
                        $this->lockManager->writeResult(false, 'Aborted by external signal.');
                        $aborted = true;
                        break;
                    }

                    $collection  = $this->buildCollection($lastSyncAt, $storeId, $page);
                    $rawProducts = array_values($collection->getItems());

                    if (empty($rawProducts)) {
                        break;
                    }

                    $products = empty($orphanedChildIdSet)
                        ? $rawProducts
                        : array_values(array_filter($rawProducts, static fn($p) =>
                            !isset($orphanedChildIdSet[(int) $p->getId()])
                        ));

                    if (!empty($products)) {
                        $count = $this->syncService->syncBatch($products, $storeId);

                        if ($count === -1) {
                            $msg = sprintf('Connection failed or invalid API key for store %d — cursor not advanced.', $storeId);
                            $this->logger->error('[SmartSearch][Cron] ' . $msg);
                            $hadFatal = true;
                            break;
                        }

                        $totalSynced += max(0, $count);
                    }

                    $page++;
                } while (count($rawProducts) === self::BATCH_SIZE);

                if ($aborted || $hadFatal) {
                    continue;
                }

                // ── Disabled/OOS sweep ───────────────────────────────────────────
                // Closes the gap the real-time observers can't cover: Magento's admin
                // "Update Attributes" mass action (status) and any bulk stock update
                // write directly via Product\Action/StockRegistry APIs and never
                // dispatch catalog_product_save_after / cataloginventory_stock_item_save_after,
                // so ProductSaveObserver/StockChangeObserver never fire for them.
                // This sweep finds anything that became disabled/OOS since the last
                // cursor (or, on a full sync, everything currently disabled/OOS) and
                // explicitly deletes it from the platform — a delete call for a product
                // already removed is a harmless no-op there.
                $deletePage = 1;
                do {
                    if (!$this->lockManager->isLocked()) {
                        $this->logger->warning('[SmartSearch][Cron] Lock file removed — sync aborted by external signal.');
                        $this->lockManager->writeResult(false, 'Aborted by external signal.');
                        $aborted = true;
                        break;
                    }

                    $delCollection = $this->buildDisabledOrOosCollection($lastSyncAt, $storeId, $deletePage);
                    $delIds        = array_map('intval', $delCollection->getAllIds());

                    if (empty($delIds)) {
                        break;
                    }

                    $delCount = $this->syncService->deleteBatch($delIds, $storeId);

                    if ($delCount === -1) {
                        $this->logger->error(sprintf(
                            '[SmartSearch][Cron] Disabled/OOS sweep: connection failed or invalid API key for store %d.',
                            $storeId
                        ));
                        $hadFatal = true;
                        break;
                    }

                    $this->logger->info(sprintf(
                        '[SmartSearch][Cron] Disabled/OOS sweep deleted %d product(s) for store %d.',
                        max(0, $delCount), $storeId
                    ));

                    $deletePage++;
                } while (count($delIds) === self::BATCH_SIZE);
            }

            if (!$aborted) {
                if ($hadFatal) {
                    $this->lockManager->writeResult(false, "Synced {$totalSynced} products before a fatal error (cursor not advanced).");
                } else {
                    $this->helper->setLastSyncAt($syncStartedAt);

                    if ($forceFullSync) {
                        $this->helper->clearFullSyncFlag();
                    }

                    $this->lockManager->writeResult(true, "Synced {$totalSynced} products.");
                }
                $this->logger->info('[SmartSearch][Cron] Done. synced=' . $totalSynced . ' cursor=' . $syncStartedAt);
            }

        } finally {
            $this->lockManager->release();
        }
    }

    /**
     * All store IDs that resolve a non-empty API key — either their own store-scoped
     * override, or the inherited website/default value if no override is set.
     */
    private function getConfiguredStoreIds(): array
    {
        $ids = [];
        foreach ($this->storeManager->getStores() as $store) {
            $sid = (int) $store->getId();
            if ($this->helper->getApiKey($sid)) {
                $ids[] = $sid;
            }
        }
        return $ids;
    }

    private function buildCollection(?string $lastSyncAt, int $storeId, int $page): \Magento\Catalog\Model\ResourceModel\Product\Collection
    {
        $collection = $this->collectionFactory->create();
        $collection->setStoreId($storeId);
        $collection->addStoreFilter($storeId);

        $collection->addAttributeToSelect([
            'name', 'sku', 'price', 'special_price', 'status', 'visibility',
            'url_key', 'description', 'short_description', 'image',
            'color', 'material', 'size', 'manufacturer', 'product_brand',
        ]);

        // Disabled-product exclusion — this collection previously had no status
        // filter, so disabled products were syncing to the platform via cron.
        $collection->addAttributeToFilter('status', Status::STATUS_ENABLED);

        if ($lastSyncAt !== null) {
            $collection->addAttributeToFilter('updated_at', ['gt' => $lastSyncAt]);
        }

        // OOS exclusion — full/cron sync only, never the real-time save observer.
        $collection->joinField(
            'is_in_stock',
            'cataloginventory_stock_item',
            'is_in_stock',
            'product_id=entity_id',
            ['stock_id' => 1],
            'inner'
        );
        $collection->addFieldToFilter('is_in_stock', 1);

        $collection->setOrder('entity_id', 'ASC');
        $collection->setPageSize(self::BATCH_SIZE);
        $collection->setCurPage($page);

        return $collection;
    }

    /**
     * Products that are disabled OR out-of-stock — the inverse of buildCollection()'s
     * filter — used to sweep-delete anything a bulk/API update pushed into that state
     * without going through the real-time observers. On a full sync ($lastSyncAt null)
     * this deliberately has no updated_at floor, so it also backfills anything that
     * became disabled/OOS before this sweep existed.
     */
    private function buildDisabledOrOosCollection(?string $lastSyncAt, int $storeId, int $page): \Magento\Catalog\Model\ResourceModel\Product\Collection
    {
        $collection = $this->collectionFactory->create();
        $collection->setStoreId($storeId);
        $collection->addStoreFilter($storeId);
        $collection->addAttributeToSelect(['status']);

        $collection->joinField(
            'is_in_stock',
            'cataloginventory_stock_item',
            'is_in_stock',
            'product_id=entity_id',
            ['stock_id' => 1],
            'left'
        );

        // status = disabled OR is_in_stock = 0 (left-joined, so NULL counts as "no stock row" too)
        $collection->addFieldToFilter(
            ['status', 'is_in_stock'],
            [
                ['eq' => Status::STATUS_DISABLED],
                ['eq' => 0],
            ]
        );

        if ($lastSyncAt !== null) {
            $collection->addAttributeToFilter('updated_at', ['gt' => $lastSyncAt]);
        }

        $collection->setOrder('entity_id', 'ASC');
        $collection->setPageSize(self::BATCH_SIZE);
        $collection->setCurPage($page);

        return $collection;
    }
}
