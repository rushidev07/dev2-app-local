<?php
declare(strict_types=1);

namespace FalcoSense\Search\Service;

use FalcoSense\Search\Helper\Data;
use FalcoSense\Search\Model\FullSyncPublisher;
use Magento\Catalog\Model\Product\Attribute\Source\Status;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Psr\Log\LoggerInterface;

class FullSyncService
{
    private const BATCH_SIZE = 500;

    public function __construct(
        private readonly CollectionFactory $collectionFactory,
        private readonly FullSyncPublisher $publisher,
        private readonly Data $helper,
        private readonly LoggerInterface $logger,
        private readonly DisabledParentResolver $disabledParentResolver,
    ) {}

    /**
     * Load every enabled, in-stock, non-superseded product ID in pages of 500,
     * publish each page as one queue message.
     * Returns ['products' => int, 'batches' => int].
     */
    public function queueAll(int $magentoStoreId = 0): array
    {
        $page         = 1;
        $totalQueued  = 0;
        $totalBatches = 0;

        // A configurable child keeps its own independent status attribute --
        // disabling the parent does NOT disable its children. Without this,
        // an individually-still-Enabled child would sync on its own even
        // though its parent (the only thing actually shown/sold) is Disabled.
        $orphanedChildIds = $this->disabledParentResolver->getOrphanedChildIds($magentoStoreId);
        $orphanedChildIdSet = array_flip($orphanedChildIds);
        if (!empty($orphanedChildIds)) {
            $this->logger->info(sprintf(
                '[SmartSearch][FullSync] Excluding %d child product(s) of a disabled parent.',
                count($orphanedChildIds)
            ));
        }

        do {
            $rawItems = $this->fetchProductPage($page, $magentoStoreId);

            if (empty($rawItems)) {
                break;
            }

            $ids = empty($orphanedChildIdSet)
                ? array_map(static fn($p) => (int) $p->getId(), $rawItems)
                : array_map(
                    static fn($p) => (int) $p->getId(),
                    array_filter($rawItems, static fn($p) =>
                        !isset($orphanedChildIdSet[(int) $p->getId()])
                    )
                );

            if (!empty($ids)) {
                $this->publisher->publishBatch($ids, $magentoStoreId);

                $count = count($ids);
                $totalQueued  += $count;
                $totalBatches++;

                $this->logger->info(sprintf(
                    '[SmartSearch][FullSync] Queued page %d: %d product IDs (running total: %d).',
                    $page,
                    $count,
                    $totalQueued
                ));
            }

            $page++;
        } while (count($rawItems) === self::BATCH_SIZE);

        $this->logger->info(sprintf(
            '[SmartSearch][FullSync] Done queuing. products=%d batches=%d',
            $totalQueued,
            $totalBatches
        ));

        return ['products' => $totalQueued, 'batches' => $totalBatches];
    }

    private function fetchProductPage(int $page, int $storeId): array
    {
        $collection = $this->collectionFactory->create();
        $collection->addAttributeToSelect(['sku']);
        $collection->addAttributeToFilter('status', Status::STATUS_ENABLED);

        // OOS exclusion — full sync only, never the real-time save observer.
        $collection->joinField(
            'is_in_stock',
            'cataloginventory_stock_item',
            'is_in_stock',
            'product_id=entity_id',
            ['stock_id' => 1],
            'inner'
        );
        $collection->addFieldToFilter('is_in_stock', 1);

        $collection->setPageSize(self::BATCH_SIZE);
        $collection->setCurPage($page);

        if ($storeId > 0) {
            $collection->addStoreFilter($storeId);
        }

        return array_values($collection->getItems());
    }
}
