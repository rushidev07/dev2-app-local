<?php
declare(strict_types=1);

namespace FalcoSense\Search\Service;

use Magento\Catalog\Model\Product\Attribute\Source\Status;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Framework\App\ResourceConnection;

/**
 * Batch/cron/full sync only — NOT used by the real-time save observer.
 *
 * A configurable product's children (size/color variants etc.) each carry
 * their OWN independent `status` attribute in Magento -- disabling the
 * parent listing does NOT automatically disable its children. Without this
 * check, a child SKU that's individually still Enabled would sync to the
 * search platform on its own, even though its parent (the only thing that
 * actually gets shown/sold as this product) is Disabled.
 *
 * Uses Magento's real parent-child relationship (catalog_product_super_link)
 * rather than any SKU-naming heuristic, so there's no risk of the false
 * positives that affect DuplicateSkuResolver's pattern-matching approach.
 */
class DisabledParentResolver
{
    public function __construct(
        private readonly CollectionFactory  $collectionFactory,
        private readonly ResourceConnection $resourceConnection,
    ) {}

    /**
     * Entity IDs of configurable-child products whose parent is Disabled,
     * for the given store (0 = default scope only).
     */
    public function getOrphanedChildIds(int $storeId = 0): array
    {
        $disabledParents = $this->collectionFactory->create();
        $disabledParents->addAttributeToFilter('type_id', 'configurable');
        $disabledParents->addAttributeToFilter('status', Status::STATUS_DISABLED);
        if ($storeId > 0) {
            $disabledParents->addStoreFilter($storeId);
        }

        $parentIds = array_map('intval', $disabledParents->getAllIds());
        if (empty($parentIds)) {
            return [];
        }

        $connection = $this->resourceConnection->getConnection();
        $childIds = $connection->fetchCol(
            $connection->select()
                ->from($this->resourceConnection->getTableName('catalog_product_super_link'), ['product_id'])
                ->where('parent_id IN (?)', $parentIds)
        );

        return array_map('intval', $childIds);
    }
}
