<?php
declare(strict_types=1);

namespace FalcoSense\Search\Block;

use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use FalcoSense\Search\Helper\Data as SmartSearchHelper;
use FalcoSense\Search\Service\SearchTokenService;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Directory\Model\RegionFactory;

class Search extends Template
{
    private SmartSearchHelper $helper;
    private SearchTokenService $tokenService;
    private CustomerSession   $customerSession;
    private RegionFactory     $regionFactory;

    public function __construct(
        Context            $context,
        SmartSearchHelper  $helper,
        SearchTokenService $tokenService,
        CustomerSession    $customerSession,
        RegionFactory      $regionFactory,
        array              $data = []
    ) {
        parent::__construct($context, $data);
        $this->helper          = $helper;
        $this->tokenService    = $tokenService;
        $this->customerSession = $customerSession;
        $this->regionFactory   = $regionFactory;
    }

    public function getSearchApiUrl(): string
    {
        $url = $this->helper->getSearchUrl();
        return $url ?: 'http://localhost:8001/api/search.php';
    }

    public function getApiKey(): string
    {
        return $this->helper->getApiKey();
    }

    public function getSearchToken(int $magentoStoreId = 0): string
    {
        return $this->tokenService->getToken($magentoStoreId);
    }

    public function getProductsApiUrl(): string
    {
        $endpoint = $this->helper->getEndpointUrl();
        if (!$endpoint) {
            return 'http://localhost:8080/api/v1/products';
        }
        $parts = parse_url($endpoint);
        $base  = ($parts['scheme'] ?? 'http') . '://' . ($parts['host'] ?? 'localhost');
        if (!empty($parts['port'])) {
            $base .= ':' . $parts['port'];
        }
        return $base . '/api/v1/products';
    }

    public function getPlatformStoreId(): int
    {
        return $this->helper->getPlatformStoreId();
    }

    public function getSuggestUrl(): string
    {
        $endpoint = $this->helper->getEndpointUrl();
        if (!$endpoint) {
            return 'http://localhost:8080/api/v1/suggest';
        }
        $parts = parse_url($endpoint);
        $base  = ($parts['scheme'] ?? 'http') . '://' . ($parts['host'] ?? 'localhost');
        if (!empty($parts['port'])) {
            $base .= ':' . $parts['port'];
        }
        return $base . '/api/v1/suggest';
    }

    public function getSearchAnalyticsUrl(): string
    {
        $endpoint = $this->helper->getEndpointUrl();
        if (!$endpoint) {
            return 'http://localhost:8080/api/v1/analytics/search';
        }
        $parts = parse_url($endpoint);
        $base  = ($parts['scheme'] ?? 'http') . '://' . ($parts['host'] ?? 'localhost');
        if (!empty($parts['port'])) {
            $base .= ':' . $parts['port'];
        }
        return $base . '/api/v1/analytics/search';
    }

    public function getSearchQuery(): string
    {
        return (string) ($this->getRequest()->getParam('q') ?? '');
    }

    /**
     * Return the full state/region name for the logged-in customer (e.g. "Texas").
     * Returns '' for guests or customers with no address.
     *
     * Address priority: default billing → default shipping → first address.
     * Multiple-address edge case: whichever has a region wins first.
     */
    public function getCustomerGeoState(): string
    {
        try {
            if (!$this->customerSession->isLoggedIn()) {
                return '';
            }

            $customer = $this->customerSession->getCustomer();
            if (!$customer || !$customer->getId()) {
                return '';
            }

            // Build a priority-ordered list of address IDs to try
            $addressIds = array_filter(array_unique([
                (int) $customer->getDefaultBilling(),
                (int) $customer->getDefaultShipping(),
            ]));

            // Fall back to all addresses if default addresses don't yield a region
            $addresses = $customer->getAddresses();
            foreach ($addresses as $addr) {
                $addressIds[] = (int) $addr->getId();
            }

            foreach ($addressIds as $addressId) {
                if ($addressId <= 0) {
                    continue;
                }
                $address = $customer->getAddressById($addressId);
                if (!$address || !$address->getId()) {
                    continue;
                }

                // Try the stored region name first
                $region = trim((string) $address->getRegion());

                // Magento sometimes only stores region_id without the text name —
                // look up the full name from the directory table as a fallback.
                if ($region === '' && $address->getRegionId()) {
                    try {
                        $regionModel = $this->regionFactory->create()->load((int) $address->getRegionId());
                        $region = trim((string) $regionModel->getName());
                    } catch (\Throwable) {
                        // ignore
                    }
                }

                if ($region !== '') {
                    return $region;
                }
            }
        } catch (\Throwable $e) {
            // Never let address lookup break the search page
        }

        return '';
    }

    /**
     * Return the full country name for the logged-in customer (e.g. "United States").
     * Returns '' for guests or customers with no address.
     *
     * Geo boost rules are stored with a full country name (set via the admin's
     * country dropdown, e.g. "United States"), not the ISO code Magento addresses
     * store (e.g. "US") — GeoBoostService's matching is an exact string compare,
     * so without this conversion a rule scoped to a country would never match
     * even when geo_state resolves correctly, since geo_country would always be
     * sent as '' and the rule's non-blank geo_country requires an exact match.
     *
     * Uses the address object's own getCountryModel() (from
     * Magento\Customer\Model\Address\AbstractAddress) rather than injecting a
     * CountryFactory dependency — adding a new constructor argument here
     * previously required the auto-generated Interceptor class to be
     * regenerated, and a stale OPcache serving the old interceptor bytecode
     * broke the live search box until it self-resolved, with no way to force
     * a PHP-FPM restart. This avoids touching the constructor at all.
     *
     * Address priority: default billing → default shipping → first address.
     */
    public function getCustomerGeoCountry(): string
    {
        try {
            if (!$this->customerSession->isLoggedIn()) {
                return '';
            }

            $customer = $this->customerSession->getCustomer();
            if (!$customer || !$customer->getId()) {
                return '';
            }

            $addressIds = array_filter(array_unique([
                (int) $customer->getDefaultBilling(),
                (int) $customer->getDefaultShipping(),
            ]));

            $addresses = $customer->getAddresses();
            foreach ($addresses as $addr) {
                $addressIds[] = (int) $addr->getId();
            }

            foreach ($addressIds as $addressId) {
                if ($addressId <= 0) {
                    continue;
                }
                $address = $customer->getAddressById($addressId);
                if (!$address || !$address->getId()) {
                    continue;
                }

                if (trim((string) $address->getCountryId()) === '') {
                    continue;
                }

                try {
                    $countryName = trim((string) $address->getCountryModel()->getName());
                } catch (\Throwable) {
                    $countryName = '';
                }

                if ($countryName !== '') {
                    return $countryName;
                }
            }
        } catch (\Throwable $e) {
            // Never let address lookup break the search page
        }

        return '';
    }
}
